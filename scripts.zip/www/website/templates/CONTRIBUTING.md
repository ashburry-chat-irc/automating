*Contributing*
====================
I am very happy you have found my CONTRIBUTING file and I am eager to have, in any form possible, your contribution to 
Trio-ircproxy and Machine Gun mSL script named Bauderr and the website/webserver named RoseMay.  
For the most part I am coding the bulk of the applications, after which it will be easier to 
contribute as there won't be such are defecit of code. You are welcome to fork the project at any time if you want to write your own app, 
just include the LICENSE (or include similar licence suitable for open source software).  I doubt anyone would want to fork at such an 
early stage of the project as the code is still messy.  Contributions may include "word of mouth" sharing of the project details as 
well as providing additional documentation, writting GitHub Issues (requesting features), Python and mSL code, and Pull Requests for
any of the files (and upload new files).  You may contribute simply by idling in #5ioE on irc.UnderNet.org however the channel is not active 
at the moment but you are still welcome to idle an irc bot or client connection. If you are planning on using Trio_ircproxy.py or 
accompanied mIRC script (Machine Gun script named Bauderr) then please leave an Issue comment with any features you would like to be 
included and I will do my best to include your feature request in the first release.  Any contribution deserves credit where 
credit is due and you may be mentioned in the appropriate section of the documentation, on the website, aswell as a "Thank-You" in this file.
So please state your nickname/name you prefer to be mentioned as and ask me on IRC or by email or write an issue requesting Contribution 
mention of yourself or another person. This file is a work in progress please feal free to update 
it as needed by either writting an Issue or sending an email to ashburry_undernet@outlook.com.

Thank you for reading.
- Ashburry	ashburry_undernet@outlook.com

*Contributers:*
====================
***#Python on irc.libera.chat***
Much Apperciation goes out to many of the people in #Python on irc.libera.chat --+
Many of the people in #Python have helped me by providing me with solutions of various problems in an professional manner.

***Ashburry --***
The founder, and coder of the bulk of the project.

*End of file*
